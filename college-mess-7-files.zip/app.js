const token=localStorage.getItem("token");
const user=JSON.parse(localStorage.getItem("user")||"null");

const $=id=>document.getElementById(id);
if(token){$("loginLink").classList.add("hidden");$("logout").classList.remove("hidden");$("orders").classList.remove("hidden");}
$("logout").onclick=()=>{localStorage.clear();location.reload()};

function headers(){return token?{"Authorization":"Bearer "+token}:{}}
function esc(v){return String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}

async function loadMenu(){
  const r=await fetch("/api/menu"), data=await r.json();
  $("menuList").innerHTML=data.length?data.map(m=>`
    <article class="meal">
      <span class="badge">${esc(m.mealType)}</span>
      <h3>${esc(m.name)}</h3>
      <p>${esc(m.description||"Freshly prepared meal")}</p>
      <div class="price">₹${Number(m.price).toFixed(2)}</div>
      ${token?`<button class="btn" onclick="order(${m.id})">Order</button>`:""}
    </article>`).join(""):"<div class='card'>No menu added for today.</div>";
}

async function order(id){
  const q=Number(prompt("Quantity","1"));
  if(!Number.isInteger(q)||q<1)return;
  const r=await fetch("/api/orders",{method:"POST",headers:{"Content-Type":"application/json",...headers()},body:JSON.stringify({menuItemId:id,quantity:q})});
  const d=await r.json(); alert(d.message||"Order placed successfully"); if(r.ok)loadOrders();
}

async function loadOrders(){
  if(!token)return;
  const r=await fetch("/api/orders/my",{headers:headers()});
  if(!r.ok)return;
  const data=await r.json();
  $("orderList").innerHTML=data.length?data.map(o=>`
    <div class="order"><b>${esc(o.menuItem.name)}</b> — Quantity: ${o.quantity}
    <small> (${new Date(o.orderedAt).toLocaleString()})</small></div>`).join("")
    :"<div class='card'>No orders yet.</div>";
}

async function login(){
  try{
    const r=await fetch("/api/auth/login",{method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({email:$("email").value,password:$("password").value})});
    const d=await r.json(); if(!r.ok)throw Error(d.message);
    localStorage.setItem("token",d.token);localStorage.setItem("user",JSON.stringify(d));location.reload();
  }catch(e){$("msg").textContent=e.message}
}

async function registerUser(){
  try{
    const r=await fetch("/api/auth/register",{method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({name:$("name").value,email:$("email").value,password:$("password").value})});
    const d=await r.json();if(!r.ok)throw Error(d.message);
    localStorage.setItem("token",d.token);location.reload();
  }catch(e){$("msg").textContent=e.message}
}

loadMenu();loadOrders();
